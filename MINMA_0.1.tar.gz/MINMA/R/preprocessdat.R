#' @title {split metabolite name function}
#' @description A function to split entry name for each metabolite
#' @param x A metabolite entry name
#' @param split A vector, each element is the char where to split
#' @return A vector, the split result for x
#' @keywords internal
#' @export
my.split<-function(x, split){
  for(i in 1:length(split))
  {
    r<-NULL
    for(j in 1:length(x))
    {
      r<-c(r, unlist(strsplit(x[j],split=split[i])))
    }
    x<-r
  }
  x
}


#' @title {Create the matched matrix }
#' @description A function to create match matrix.
#' @param m.all A data frame, KEGG ID, adduct, m/z
#' @param nodes A vector, the entry name starts with "C" or "G"
#' @param dat.mz A vector, the mz value for each entry
#' @param tol tolerance, default 1e-5
#' @return A matrix, row=features, col="ID", "ion", "target mz", "row match", "data mz"
#' @keywords internal
#' @export
match.nodes<-function(m.all, nodes,  dat.mz, tol=1e-5){
  m.all[,2]<-as.vector(m.all[,2])
  all.ions<-as.vector(unique(m.all[,2]))
  nodes.m<-matrix(NA, nrow=2, ncol=5)
  colnames(nodes.m)<-c("ID", "ion", "target mz", "row match", "data mz")

  for(i in 1:length(nodes))
  {
    sel<-which(m.all[,1] == nodes[i])
    if(length(sel)>0)
    {
      this<-m.all[sel,]
      for(j in 1:nrow(this))
      {
        targ<-this[j,3]
        curr.ion<-this[j,2]
        found<-which(abs(targ-dat.mz) <= targ*tol)
        if(length(found)>0)
        {
          for(k in 1:length(found))
          {
            nodes.m<-rbind(nodes.m, c(nodes[i], curr.ion, targ,found[k], dat.mz[found[k]]))
          }
        }
      }
    }
  }
  nodes.m<-nodes.m[-1:-2,]
  return(nodes.m)
}



#' @title {Create a detailed metabolite table}
#' @description A function to transform raw information from KEGG database to a metabolite table with related information for future use
#' @param metabolite.table A dataframe where 4 variables are measured for each of the compounds: formula, entry, entry, mass
#' @param adduct.table A data frame where 4 variables are recorded: adduct, divider, addition, charge
#' @param ion.mode Either + or -, default: +
#' @return A data frame, each line is a compound, measured informaiton including: compound names, entry, entry, mass, ion.type, m.z, Number_profiles_processed, Percent_found, mz_min, mz_max, RT_mean, RT_sd, RT_min, RT_max, int_mean(log), int_sd(log), int_min(log), int_max(log).
#' @keywords internal
#' @export
make.known.table<-function (metabolite.table, adduct.table, ion.mode = "+"){
  metabolite.table <- metabolite.table[order(metabolite.table[,
                                                              4]), ]
  for (i in 1:3) metabolite.table[, i] <- as.vector(metabolite.table[,
                                                                     i])
  metabolite.table <- cbind(metabolite.table, matrix(NA, nrow = nrow(metabolite.table),
                                                     ncol = 14))
  colnames(metabolite.table)[5:ncol(metabolite.table)] <- c("ion.type",
                                                            "m.z", "Number_profiles_processed", "Percent_found",
                                                            "mz_min", "mz_max", "RT_mean", "RT_sd", "RT_min", "RT_max",
                                                            "int_mean(log)", "int_sd(log)", "int_min(log)", "int_max(log)")
  l <- nchar(metabolite.table[, 1])
  last.char <- substr(metabolite.table[, 1], l, l)
  sel <- which(last.char == "+" | last.char == "-")
  rm.first.row <- TRUE
  new.table <- matrix(NA, nrow = 1, ncol = ncol(metabolite.table))
  colnames(new.table) <- colnames(metabolite.table)
  if (length(sel) > 0) {
    new.table <- rbind(new.table, metabolite.table[sel, ])
    l <- nchar(new.table[, 1]) - 1
    num.charge <- substr(new.table[, 1], l, l)
    num.charge <- as.numeric(num.charge)
    new.table[, 5] <- "orig"
    new.table[, 6] <- new.table[, 4]
    new.table[which(!is.na(num.charge)), 6] <- new.table[which(!is.na(num.charge)),
                                                         6]/num.charge[which(!is.na(num.charge))]
    metabolite.table <- metabolite.table[-sel, ]
  }
  n <- 1
  m <- 2
  to.remove <- rep(0, nrow(metabolite.table))
  while (m <= nrow(metabolite.table)) {
    if (abs(metabolite.table[m, 4] - metabolite.table[n,
                                                      4]) < 1e-10) {
      if (metabolite.table[n, 1] != metabolite.table[m,
                                                     1])
        metabolite.table[n, 1] <- paste(metabolite.table[n,
                                                         1], metabolite.table[m, 1], sep = "/")
      for (j in 2:3) metabolite.table[n, j] <- paste(metabolite.table[n,
                                                                      j], metabolite.table[m, j], sep = "/")
      to.remove[m] <- 1
      m <- m + 1
      #       cat(m)
      #       cat(".")
    }
    else {
      n <- m
      m <- m + 1
    }
    #cat("(", n, m, ")")
  }
  if (sum(to.remove) > 0)
    metabolite.table <- metabolite.table[-which(to.remove ==
                                                  1), ]
  neutral.table <- metabolite.table
  for (n in 1:nrow(adduct.table)) {
    this <- neutral.table
    this[, 5] <- adduct.table[n, 1]
    this[, 6] <- neutral.table[, 4]/adduct.table[n, 2] +
      adduct.table[n, 3]
    new.table <- rbind(new.table, this)
  }
  if (rm.first.row)
    new.table <- new.table[-1, ]
  to.remove <- rep(0, nrow(new.table))
  l <- nchar(new.table[, 1])
  last.char <- substr(new.table[, 1], l, l)
  if (ion.mode == "+")
    to.remove[which(last.char == "-")] <- 1
  if (ion.mode == "-")
    to.remove[which(last.char == "+")] <- 1
  if (sum(to.remove) > 0)
    new.table <- new.table[-which(to.remove == 1), ]
  new.table <- new.table[order(new.table[, 6]), ]
  n <- 1
  m <- 2
  to.remove <- rep(0, nrow(new.table))
  while (m <= nrow(new.table)) {
    if (abs(new.table[m, 6] - new.table[n, 6]) < 1e-10) {
      if (new.table[n, 1] != new.table[m, 1])
        new.table[n, 1] <- paste(new.table[n, 1], new.table[m,
                                                            1], sep = "/")
      for (j in 2:5) new.table[n, j] <- paste(new.table[n,
                                                        j], new.table[m, j], sep = "/")
      to.remove[m] <- 1
      m <- m + 1
      #       cat(m)
      #       cat(".")
    }
    else {
      n <- m
      m <- m + 1
    }
    #cat("*(", n, m, ")")

  }
  if (sum(to.remove) > 0)
    new.table <- new.table[-which(to.remove == 1), ]
  return(new.table)
}



#' @title {The main function used to create the matched matrix}
#' @description The main function used to create the matched matrix
#' @param dat.mat, data expression matrix.
#' @param grph graph object
#' @param adduct.table  A data frame where 4 variables are recorded: adduct, divider, addition, charge
#' @param compounds KEGG metabolomics information
#' @param mz.tol mz tolerance
#' @param ion.mode Either + or -, default: +
#' @return A matrix, row=features, col="ID", "ion", "target mz", "row match", "data mz"
#' @keywords internal
#' @export
match.data.KEGG<-function(data.mat, networknodename, adduct.table, compounds, mz.tol, ion.mode){
  # first generate theoretical m/z table
  mets<-matrix(0, ncol=4, nrow=length(compounds))
  for(i in 1:length(compounds))
  {
    this<-compounds[[i]]
    this.formula<-NA
    if(!is.null(this[[1]]$FORMULA)) this.formula<-this[[1]]$FORMULA
    this.mass<-NA
    if(!is.null(this[[1]]$EXACT_MASS)) this.mass<-this[[1]]$EXACT_MASS

    mets[i,]<-c(this.formula, this[[1]]$ENTRY, this[[1]]$ENTRY, this.mass)
    #print(this[[1]]$ENTRY)
  }
  mets<-as.data.frame(mets)
  mets[,4]<-as.numeric(as.vector(mets[,4]))
  mets<-mets[!is.na(mets[,4]),]

  m<-make.known.table(mets, adduct.table, ion.mode=ion.mode)


  m.all<-matrix(0, ncol=3, nrow=nrow(m)*10)
  m.counter<-0
  for(i in 1:nrow(m))
  {
    a<-my.split(m[i,3],c("/", " "))
    a<-a[which(substr(a,1,1) %in% c("C", "G"))]
    if(length(a)>0)
    {
      for(j in 1:length(a))
      {
        m.counter<-m.counter+1
        m.all[m.counter,]<-c(a[j], m[i,5],m[i,6])
      }
    }
  }
  m.all<-m.all[1:m.counter,]
  m.all<-as.data.frame(m.all)
  m.all[,3]<-as.numeric(as.vector(m.all[,3]))

  colnames(m.all)<-c("KEGG ID", "adduct", "m/z")

  nodes<-networknodename


  mz<-data.mat[,1]


  matched<-match.nodes(m.all, nodes, mz, tol=mz.tol)

  matched
}

#' @title {Data matrix pre-processing}
#' @aliases preprocess.dat
#' @name preprocess.dat
#' @description A function to pre-process data based on user input-- the expression matrix and inherent KEGG database
#' @usage preprocess.dat(expdat,networknodename=NULL,adduct=NULL, ms=NULL,mz.eps=1e-5, ionMode="+")
#' @param expdat An LC-MS metabolomics data matrix with missing values where features in the rows, samples in the columns.
#' @param networknodename The metabolite names being considered.
#' @param adduct A data frame either provided by the user or the default "adduct.table.bin", this dataframe is of 4 variables: adduct="2M-H", divider=3, addition=1.01, charge="1-" as an example.
#' @param ms A detailed list, each element contains compound information, like: "ENTRY", "FORMULA", "EXACT_MASS", "MOL_WEIGHT", "REMARK", "REACTION", "PATHWAY", "MODULE", "ENZYME", "BRITE", "DBLINKS". Either provided by the user or the default information extracted from "KEGG.compounds.bin" / "KEGG.glycans.bin".
#' @param mz.eps The tolerance of m/z. Default 1e-5.
#' @param ionMode A char can be either "+" or "-". Used if network, matchdat, ms, adduct are all needs to parsing. Default "+"
#' @details The compounds information is firstly extracted from KEGG database, then the entries with missing mass values are removed. An iterate procedure is used to compare each pair of the compounds once at a time: if they are of the mass difference within a pre-defined tolerance, they are combined as one compound in the matrix.
#' Secondly, the compounds matrix is extended by adding different ions indicated by adduct table. Again, an iterative comparing procedure is carried out so that any pairs with the mass difference within a pre-defined tolerance are combined as one compound. \\ Note, each compound's mass over charge ratio is calculated along the way.
#' Finally, all the compounds where it is ever appeared in the network, the information: "KEGG ID", "adduct", "m/z" are output as the matched data information.
#' @return A list object, contains:
#'  \item{dat.exp}{the LC-MS metabolomics data matrix}
#'  \item{dat.graph}{the network adjacency matrix}
#'  \item{dat.adduct}{the adduct table}
#'  \item{dat.match}{the matrix indicating matching information, each row represents one metabolite, column information includes: ID='C00013', ion='M+H', 'target mz'=178.950476, 'row match'=1198, 'data mz'=178.949981148383 as an example.}
#' @examples
#' \dontrun{
#' data(metabolomics) #suppose we only have LC-MS metabolomics data matrix.
#' res.preprocess=preprocess.dat(dat.exp)
#' print(res.preprocess$dat.match)
#' }
#' @export
preprocess.dat=function(expdat,networknodename=NULL,adduct=NULL, ms=NULL, mz.eps=1e-5,ionMode="+"){
  if(is.null(networknodename)){
    data(network)
    networknodename=rownames(network)

  }
  if(is.null(ms)){
    data(compounds.rda)
  }
  if(is.null(adduct)){
    data(adduct.rda)
  }
  matchdat=MINMA::match.data.KEGG(expdat, networknodename, adduct.table, compounds, mz.tol=mz.eps, ion.mode=ionMode)
  return(list(dat.exp=expdat,dat.graph=network,dat.adduct=adduct,dat.match=matchdat))
}
