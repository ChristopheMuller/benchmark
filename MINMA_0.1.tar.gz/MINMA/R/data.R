#' LC-MS Metabolomics dataset
#'
#' A dataset containing LC-MS metabolomics data matrix and correponding network information etc.
#'
#' @docType data
#' @keywords datasets
#' @name metabolomics
#' @aliases metabolomics
#' @usage data(metabolomics)
#' @format A R object contains:
#' \itemize{
#' \item dat.exp, a matrix. 1-2 columns contains mz/RT info, which will be used as dat.ions. 3-ncol(dat.exp) is the LC-MS metabolomics data matrix with missing values.
#' \item dat.adduct, a data.frame. Each obs is of 4 variables, adduct, divider, addition, charge.
#' \item dat.match, each row is one entry about "ID", "ion", "target mz", "row match", "data mz"
#' \item dat.graph, an adjacency matrix 0/1 it is undirected network based on existing knowledge.
#' }
NULL




#' dat.exp
#'
#' A LC-MS metabolomics data matrix.
#'
#' @details dat.exp
#' @docType data
#' @keywords datasets, internal
#' @name dat.exp
#' @format NULL
NULL




#' dat.adduct
#'
#' A dat.adduct dataset
#'
#' @details dat.adduct
#' @docType data
#' @keywords datasets, internal
#' @name dat.adduct
#' @format NULL
NULL





#' dat.match
#'
#' A dat.match dataset
#'
#' @details dat.match
#' @docType data
#' @keywords datasets, internal
#' @name dat.match
#' @format NULL
NULL


#' dat.graph
#'
#' A dat.graph dataset
#'
#' @details dat.graph
#' @docType data
#' @keywords datasets, internal
#' @name dat.graph
#' @format NULL
NULL















