#' @title {Calculating the normalized root mean squared error (NRMSE)}
#' @aliases NRMSE
#' @name NRMSE
#' @description A function to calculate normalized root mean squared error (NRMSE)
#' @usage NRMSE(dat.impute, dat.true)
#' @param dat.impute A vector, the imputed data. Note: check if there is any NAs, if there is, NAs are automatically removed for calculation.
#' @param dat.true A vector, the underlying true values.
#' @return the NRMSE value.
#' @export
NRMSE=function(dat.impute, dat.true){
  return(sqrt(sum((dat.impute-dat.true)*(dat.impute-dat.true))/length(dat.true)/stats::var(dat.true)))
}
